Keyboard mapping;

r:	reload, need ammo in inventory.
space:	use stamina refill pills, need green pills in inventory.
m:	toggle whole map and local view.
f:	drop selected item, needs to be hold or the item will be picked up again.
R:	restart game.

mouse left:	use selected item.
mouse right:	sprint uses stamina.

gamepad mapping;

a: hold to drop item.
b: reload gun.
x: use green stamina pills

lb: sprint
rb: shoot

hat: inventory
LT/RT: inventory left/right
